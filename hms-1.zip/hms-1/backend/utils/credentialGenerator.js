const crypto = require('crypto');

// Generate unique username for doctor
const generateUsername = (firstName, lastName) => {
  const baseUsername = `dr${firstName.toLowerCase()}${lastName.toLowerCase()}`;
  const randomSuffix = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
  return `${baseUsername}${randomSuffix}`;
};

// Generate strong password
const generatePassword = () => {
  const length = 12;
  const charset = {
    lowercase: 'abcdefghijklmnopqrstuvwxyz',
    uppercase: 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',
    numbers: '0123456789',
    symbols: '!@#$%^&*()_+-=[]{}|;:,.<>?'
  };
  
  let password = '';
  
  // Ensure at least one character from each category
  password += charset.lowercase[Math.floor(Math.random() * charset.lowercase.length)];
  password += charset.uppercase[Math.floor(Math.random() * charset.uppercase.length)];
  password += charset.numbers[Math.floor(Math.random() * charset.numbers.length)];
  password += charset.symbols[Math.floor(Math.random() * charset.symbols.length)];
  
  // Fill the rest randomly
  const allChars = charset.lowercase + charset.uppercase + charset.numbers + charset.symbols;
  for (let i = 4; i < length; i++) {
    password += allChars[Math.floor(Math.random() * allChars.length)];
  }
  
  // Shuffle the password
  return password.split('').sort(() => Math.random() - 0.5).join('');
};

// Check if username is unique
const isUsernameUnique = async (username, User) => {
  const existingUser = await User.findOne({ username });
  return !existingUser;
};

// Generate unique credentials
const generateDoctorCredentials = async (firstName, lastName, User) => {
  let username = generateUsername(firstName, lastName);
  let attempts = 0;
  
  // Ensure username is unique
  while (!(await isUsernameUnique(username, User)) && attempts < 10) {
    username = generateUsername(firstName, lastName);
    attempts++;
  }
  
  if (attempts >= 10) {
    throw new Error('Unable to generate unique username');
  }
  
  const password = generatePassword();
  
  return {
    username,
    password
  };
};

module.exports = {
  generateDoctorCredentials,
  generateUsername,
  generatePassword
};
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
    username: {
        type: String,
        required: true,
        unique: true,
        trim: true
    },
    password: {
        type: String,
        required: true,
        minlength: 6
    },
    role: {
        type: String,
        enum: ['admin', 'doctor', 'inventory'],
        required: true
    },
    firstName: {
        type: String,
        required: true
    },
    lastName: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    phone: {
        type: String,
        required: true
    },
    specialization: {
        type: String,
        required: function () { return this.role === 'doctor'; }
    },
    department: {
        type: String,
        required: false  // Changed from function() { return this.role === 'doctor'; }
    },
    age: {
        type: Number,
        required: function () { return this.role === 'doctor'; }
    },
    gender: {
        type: String,
        enum: ['male', 'female', 'other'],
        required: function () { return this.role === 'doctor'; }
    },
    experience: {
        type: Number,
        required: function () { return this.role === 'doctor'; }
    },
    qualification: {
        type: String,
        required: function () { return this.role === 'doctor'; }
    },
    isActive: {
        type: Boolean,
        default: true
    }
}, {
    timestamps: true
});

// Hash password before saving
userSchema.pre('save', async function (next) {
    if (!this.isModified('password')) {
        next();
    }
    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
});

// Compare password method
userSchema.methods.matchPassword = async function (enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model('User', userSchema);
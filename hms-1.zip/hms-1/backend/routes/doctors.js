const express = require('express');
const { body } = require('express-validator');
const {
  getDoctors,
  getDoctor,
  registerDoctor,
  updateDoctor,
  deleteDoctor
} = require('../controllers/doctorController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// Doctor validation rules
const doctorValidation = [
  body('firstName').notEmpty().withMessage('First name is required'),
  body('lastName').notEmpty().withMessage('Last name is required'),
  body('email').isEmail().withMessage('Valid email is required'),
  body('phone').notEmpty().withMessage('Phone number is required'),
  body('specialization').notEmpty().withMessage('Specialization is required'),
  body('age').isInt({ min: 18, max: 100 }).withMessage('Age must be between 18 and 100'),
  body('gender').isIn(['male', 'female', 'other']).withMessage('Gender must be male, female, or other'),
  body('experience').isInt({ min: 0 }).withMessage('Experience must be a positive number'),
  body('qualification').notEmpty().withMessage('Qualification is required')
];

router.route('/')
  .get(protect, authorize('admin'), getDoctors)
  .post(protect, authorize('admin'), doctorValidation, registerDoctor);

router.route('/:id')
  .get(protect, authorize('admin', 'doctor'), getDoctor)
  .put(protect, authorize('admin'), updateDoctor)
  .delete(protect, authorize('admin'), deleteDoctor);

module.exports = router;
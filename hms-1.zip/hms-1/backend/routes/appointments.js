const express = require('express');
const { body } = require('express-validator');
const {
  getAppointments,
  getAppointment,
  createAppointment,
  updateAppointment,
  deleteAppointment
} = require('../controllers/appointmentController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// Appointment validation rules
const appointmentValidation = [
  body('patient').notEmpty().withMessage('Patient is required'),
  body('doctor').notEmpty().withMessage('Doctor is required'),
  body('appointmentDate').isISO8601().withMessage('Valid appointment date is required'),
  body('appointmentTime').notEmpty().withMessage('Appointment time is required'),
  body('reason').notEmpty().withMessage('Reason for appointment is required')
];

router.route('/')
  .get(protect, authorize('admin', 'doctor'), getAppointments)
  .post(protect, authorize('admin', 'doctor'), appointmentValidation, createAppointment);

router.route('/:id')
  .get(protect, authorize('admin', 'doctor'), getAppointment)
  .put(protect, authorize('admin', 'doctor'), updateAppointment)
  .delete(protect, authorize('admin'), deleteAppointment);

module.exports = router;
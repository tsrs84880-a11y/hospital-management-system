const express = require('express');
const { body } = require('express-validator');
const {
  getInventoryItems,
  getInventoryItem,
  createInventoryItem,
  updateInventoryItem,
  deleteInventoryItem,
  getInventoryStats
} = require('../controllers/inventoryController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// Inventory validation rules
const inventoryValidation = [
  body('itemName').notEmpty().withMessage('Item name is required'),
  body('category').isIn(['Medicine', 'Equipment', 'Supplies', 'Other']).withMessage('Valid category is required'),
  body('quantity').isNumeric().withMessage('Quantity must be a number'),
  body('unit').notEmpty().withMessage('Unit is required'),
  body('unitPrice').isNumeric().withMessage('Unit price must be a number')
];

// Special route for stats
router.get('/stats', protect, authorize('admin', 'inventory'), getInventoryStats);

router.route('/')
  .get(protect, authorize('admin', 'inventory'), getInventoryItems)
  .post(protect, authorize('admin', 'inventory'), inventoryValidation, createInventoryItem);

router.route('/:id')
  .get(protect, authorize('admin', 'inventory'), getInventoryItem)
  .put(protect, authorize('admin', 'inventory'), updateInventoryItem)
  .delete(protect, authorize('admin'), deleteInventoryItem);

module.exports = router;
const express = require('express');
const { body } = require('express-validator');
const {
  getPatients,
  getPatient,
  createPatient,
  updatePatient,
  deletePatient
} = require('../controllers/patientController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

// Patient validation rules
const patientValidation = [
  body('firstName').notEmpty().withMessage('First name is required'),
  body('lastName').notEmpty().withMessage('Last name is required'),
  body('dateOfBirth').isISO8601().withMessage('Valid date of birth is required'),
  body('gender').isIn(['Male', 'Female', 'Other']).withMessage('Valid gender is required'),
  body('phone').notEmpty().withMessage('Phone number is required'),
  body('email').isEmail().withMessage('Valid email is required')
];

router.route('/')
  .get(protect, authorize('admin', 'doctor'), getPatients)
  .post(protect, authorize('admin', 'doctor'), patientValidation, createPatient); // Allow doctors to create patients

router.route('/:id')
  .get(protect, authorize('admin', 'doctor'), getPatient)
  .put(protect, authorize('admin'), updatePatient)
  .delete(protect, authorize('admin'), deletePatient);

module.exports = router;
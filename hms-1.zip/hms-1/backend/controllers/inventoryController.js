const Inventory = require('../models/Inventory');
const { validationResult } = require('express-validator');

// @desc    Get all inventory items
// @route   GET /api/inventory
// @access  Private (Admin, Inventory)
const getInventoryItems = async (req, res) => {
  try {
    const { category, lowStock } = req.query;
    let query = {};
    
    if (category) {
      query.category = category;
    }
    
    if (lowStock === 'true') {
      query.$expr = { $lte: ['$quantity', '$minStockLevel'] };
    }
    
    const items = await Inventory.find(query)
      .populate('updatedBy', 'firstName lastName')
      .sort({ lastUpdated: -1 });
    
    res.json({ success: true, items });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get single inventory item
// @route   GET /api/inventory/:id
// @access  Private (Admin, Inventory)
const getInventoryItem = async (req, res) => {
  try {
    const item = await Inventory.findById(req.params.id)
      .populate('updatedBy', 'firstName lastName');
    
    if (!item) {
      return res.status(404).json({ message: 'Inventory item not found' });
    }
    
    res.json({ success: true, item });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Create new inventory item
// @route   POST /api/inventory
// @access  Private (Admin, Inventory)
const createInventoryItem = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    // Generate item ID
    const itemCount = await Inventory.countDocuments();
    const itemId = `INV${String(itemCount + 1).padStart(4, '0')}`;

    const item = await Inventory.create({
      ...req.body,
      itemId,
      updatedBy: req.user.id
    });

    const populatedItem = await Inventory.findById(item._id)
      .populate('updatedBy', 'firstName lastName');

    res.status(201).json({ success: true, item: populatedItem });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ message: 'Item with this ID already exists' });
    }
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Update inventory item
// @route   PUT /api/inventory/:id
// @access  Private (Admin, Inventory)
const updateInventoryItem = async (req, res) => {
  try {
    const item = await Inventory.findByIdAndUpdate(
      req.params.id,
      {
        ...req.body,
        lastUpdated: Date.now(),
        updatedBy: req.user.id
      },
      { new: true, runValidators: true }
    ).populate('updatedBy', 'firstName lastName');

    if (!item) {
      return res.status(404).json({ message: 'Inventory item not found' });
    }

    res.json({ success: true, item });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Delete inventory item
// @route   DELETE /api/inventory/:id
// @access  Private (Admin)
const deleteInventoryItem = async (req, res) => {
  try {
    const item = await Inventory.findById(req.params.id);

    if (!item) {
      return res.status(404).json({ message: 'Inventory item not found' });
    }

    await item.deleteOne();
    res.json({ success: true, message: 'Inventory item deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get inventory statistics
// @route   GET /api/inventory/stats
// @access  Private (Admin, Inventory)
const getInventoryStats = async (req, res) => {
  try {
    const totalItems = await Inventory.countDocuments();
    const lowStockItems = await Inventory.countDocuments({
      $expr: { $lte: ['$quantity', '$minStockLevel'] }
    });
    const expiringSoon = await Inventory.countDocuments({
      expiryDate: {
        $lte: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days from now
      }
    });
    
    const categoryStats = await Inventory.aggregate([
      {
        $group: {
          _id: '$category',
          count: { $sum: 1 },
          totalValue: { $sum: { $multiply: ['$quantity', '$unitPrice'] } }
        }
      }
    ]);

    res.json({
      success: true,
      stats: {
        totalItems,
        lowStockItems,
        expiringSoon,
        categoryStats
      }
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

module.exports = {
  getInventoryItems,
  getInventoryItem,
  createInventoryItem,
  updateInventoryItem,
  deleteInventoryItem,
  getInventoryStats
};
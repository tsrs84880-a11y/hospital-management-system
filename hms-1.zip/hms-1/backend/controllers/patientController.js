const Patient = require('../models/Patient');
const { validationResult } = require('express-validator');

// @desc    Get all patients
// @route   GET /api/patients
// @access  Private (Admin, Doctor)
const getPatients = async (req, res) => {
  try {
    let query = {};
    
    // If user is a doctor, only show their assigned patients
    if (req.user.role === 'doctor') {
      query.assignedDoctor = req.user.id;
    }
    
    const patients = await Patient.find(query)
      .populate('assignedDoctor', 'firstName lastName specialization')
      .sort({ createdAt: -1 });
    
    res.json({ success: true, patients });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Get single patient
// @route   GET /api/patients/:id
// @access  Private
const getPatient = async (req, res) => {
  try {
    const patient = await Patient.findById(req.params.id)
      .populate('assignedDoctor', 'firstName lastName specialization');
    
    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }
    
    // Check if doctor can access this patient
    if (req.user.role === 'doctor' && patient.assignedDoctor._id.toString() !== req.user.id) {
      return res.status(403).json({ message: 'Not authorized to access this patient' });
    }
    
    res.json({ success: true, patient });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Create new patient
// @route   POST /api/patients
// @access  Private (Admin, Doctor)
const createPatient = async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    // Calculate age from date of birth if not provided
    let { age, dateOfBirth, ...otherData } = req.body;
    
    if (!age && dateOfBirth) {
      const today = new Date();
      const birthDate = new Date(dateOfBirth);
      age = today.getFullYear() - birthDate.getFullYear();
      const monthDiff = today.getMonth() - birthDate.getMonth();
      
      if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
      }
    }

    // Generate patient ID
    const patientCount = await Patient.countDocuments();
    const patientId = `PAT${String(patientCount + 1).padStart(4, '0')}`;

    // Prepare patient data
    const patientData = {
      ...otherData,
      dateOfBirth,
      age,
      patientId
    };

    // If the user is a doctor, automatically assign them as the doctor
    if (req.user.role === 'doctor') {
      patientData.assignedDoctor = req.user.id;
    }

    const patient = await Patient.create(patientData);

    // Populate the assignedDoctor field for response
    await patient.populate('assignedDoctor', 'firstName lastName specialization');

    res.status(201).json({ success: true, patient });
  } catch (error) {
    console.error('Patient creation error:', error); // Add logging
    if (error.code === 11000) {
      return res.status(400).json({ message: 'Patient with this email already exists' });
    }
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Update patient
// @route   PUT /api/patients/:id
// @access  Private (Admin)
const updatePatient = async (req, res) => {
  try {
    const patient = await Patient.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    ).populate('assignedDoctor', 'firstName lastName specialization');

    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    res.json({ success: true, patient });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

// @desc    Delete patient
// @route   DELETE /api/patients/:id
// @access  Private (Admin)
const deletePatient = async (req, res) => {
  try {
    const patient = await Patient.findById(req.params.id);

    if (!patient) {
      return res.status(404).json({ message: 'Patient not found' });
    }

    await patient.deleteOne();
    res.json({ success: true, message: 'Patient deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
};

module.exports = {
  getPatients,
  getPatient,
  createPatient,
  updatePatient,
  deletePatient
};
const Appointment = require('../models/Appointment');
const Patient = require('../models/Patient');
const User = require('../models/User');
const { validationResult } = require('express-validator');

// Helper function to emit socket events
const emitAppointmentUpdate = (req, eventType, appointment) => {
  const io = req.app.get('socketio');
  if (io) {
    // Get the creator's socket ID to exclude them from receiving their own updates
    const creatorSocketId = req.user.socketId;
    
    // Emit to admin room
    io.to('admin').emit('appointment-update', {
      type: eventType,
      appointment
    });
    
    // Emit to specific doctor
    const doctorId = appointment.doctor._id || appointment.doctor;
    io.to(`user-${doctorId}`).emit('appointment-update', {
      type: eventType,
      appointment
    });
    
    // Emit to all doctors for general updates
    io.to('doctor').emit('appointment-update', {
      type: eventType,
      appointment
    });
  }
};

// @desc    Get all appointments
// @route   GET /api/appointments
// @access  Private
const getAppointments = async (req, res) => {
    try {
        let query = {};

        // If user is a doctor, only show their appointments
        if (req.user.role === 'doctor') {
            query.doctor = req.user.id;
        }

        const appointments = await Appointment.find(query)
            .populate('patient', 'firstName lastName patientId phone')
            .populate('doctor', 'firstName lastName specialization')
            .populate('createdBy', 'firstName lastName role')
            .sort({ createdAt: -1, appointmentDate: 1, appointmentTime: 1 }); // Sort by creation date descending, then by appointment date/time

        res.json({ success: true, data: appointments });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

// @desc    Get single appointment
// @route   GET /api/appointments/:id
// @access  Private
const getAppointment = async (req, res) => {
    try {
        const appointment = await Appointment.findById(req.params.id)
            .populate('patient', 'firstName lastName patientId phone email')
            .populate('doctor', 'firstName lastName specialization')
            .populate('createdBy', 'firstName lastName role');

        if (!appointment) {
            return res.status(404).json({ message: 'Appointment not found' });
        }

        // Check if doctor can access this appointment
        if (req.user.role === 'doctor' && appointment.doctor._id.toString() !== req.user.id) {
            return res.status(403).json({ message: 'Not authorized to access this appointment' });
        }

        res.json({ success: true, data: appointment });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

// @desc    Create new appointment
// @route   POST /api/appointments
// @access  Private (Admin, Doctor)
const createAppointment = async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({ errors: errors.array() });
        }

        const { patient, doctor, appointmentDate, appointmentTime, reason } = req.body;

        // Verify patient exists
        const patientExists = await Patient.findById(patient);
        if (!patientExists) {
            return res.status(404).json({ message: 'Patient not found' });
        }

        // Verify doctor exists
        const doctorExists = await User.findOne({ _id: doctor, role: 'doctor' });
        if (!doctorExists) {
            return res.status(404).json({ message: 'Doctor not found' });
        }

        // Check for duplicate appointments (same patient, doctor, date, and time)
        const duplicateAppointment = await Appointment.findOne({
            patient,
            doctor,
            appointmentDate: new Date(appointmentDate),
            appointmentTime: appointmentTime,
            status: { $ne: 'cancelled' }
        });

        if (duplicateAppointment) {
            return res.status(400).json({ message: 'An appointment already exists for this patient with this doctor at the specified time' });
        }

        // Check for conflicting appointments (doctor availability) - FIXED LOGIC
        const conflictingAppointment = await Appointment.findOne({
            doctor,
            appointmentDate: new Date(appointmentDate),
            appointmentTime: appointmentTime,
            status: { $ne: 'cancelled' }
        });

        // If there's any conflicting appointment, reject it (doctor can only see one patient at a time)
        if (conflictingAppointment) {
            return res.status(400).json({ 
                message: 'Doctor is not available at this time. Another appointment is already scheduled.' 
            });
        }

        // Generate unique appointment ID with retry logic
        let appointmentId;
        let attempts = 0;
        const maxAttempts = 5;
        
        while (attempts < maxAttempts) {
            try {
                // Get the latest appointment ID and increment
                const lastAppointment = await Appointment.findOne({}, {}, { sort: { 'createdAt': -1 } });
                let nextNumber = 1;
                
                if (lastAppointment && lastAppointment.appointmentId) {
                    const lastNumber = parseInt(lastAppointment.appointmentId.replace('APT', ''));
                    nextNumber = lastNumber + 1;
                }
                
                appointmentId = `APT${String(nextNumber).padStart(4, '0')}`;
                
                // Try to create the appointment with this ID
                const appointment = await Appointment.create({
                    appointmentId,
                    patient,
                    doctor,
                    appointmentDate: new Date(appointmentDate),
                    appointmentTime: appointmentTime,
                    reason,
                    createdBy: req.user.id
                });

                const populatedAppointment = await Appointment.findById(appointment._id)
                    .populate('patient', 'firstName lastName patientId')
                    .populate('doctor', 'firstName lastName specialization')
                    .populate('createdBy', 'firstName lastName role');

                // Emit real-time update
                emitAppointmentUpdate(req, 'created', populatedAppointment);

                return res.status(201).json({ success: true, data: populatedAppointment });
                
            } catch (createError) {
                if (createError.code === 11000 && createError.keyPattern?.appointmentId) {
                    // Duplicate key error for appointmentId, retry with next number
                    attempts++;
                    console.log(`Duplicate appointmentId ${appointmentId}, retrying... (attempt ${attempts})`);
                    continue;
                } else {
                    // Different error, throw it
                    throw createError;
                }
            }
        }
        
        // If we've exhausted all attempts
        throw new Error('Unable to generate unique appointment ID after multiple attempts');
        
    } catch (error) {
        console.error('Create appointment error:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

// @desc    Update appointment
// @route   PUT /api/appointments/:id
// @access  Private (Admin, Doctor)
const updateAppointment = async (req, res) => {
    try {
        const appointment = await Appointment.findById(req.params.id);

        if (!appointment) {
            return res.status(404).json({ message: 'Appointment not found' });
        }

        // Check if doctor can update this appointment
        if (req.user.role === 'doctor' && appointment.doctor.toString() !== req.user.id) {
            return res.status(403).json({ message: 'Not authorized to update this appointment' });
        }

        // Prepare update data with correct field mapping
        const updateData = {
            ...req.body
        };

        // Handle date field mapping if needed
        if (req.body.appointmentDate) {
            updateData.appointmentDate = new Date(req.body.appointmentDate);
        }

        const updatedAppointment = await Appointment.findByIdAndUpdate(
            req.params.id,
            updateData,
            { new: true, runValidators: true }
        )
            .populate('patient', 'firstName lastName patientId')
            .populate('doctor', 'firstName lastName specialization')
            .populate('createdBy', 'firstName lastName role');

        // Emit real-time update
        emitAppointmentUpdate(req, 'updated', updatedAppointment);

        res.json({ success: true, data: updatedAppointment });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

// @desc    Delete appointment
// @route   DELETE /api/appointments/:id
// @access  Private (Admin)
const deleteAppointment = async (req, res) => {
    try {
        const appointment = await Appointment.findById(req.params.id)
            .populate('patient', 'firstName lastName patientId')
            .populate('doctor', 'firstName lastName specialization');

        if (!appointment) {
            return res.status(404).json({ message: 'Appointment not found' });
        }

        // Emit real-time update before deletion
        emitAppointmentUpdate(req, 'deleted', appointment);

        await appointment.deleteOne();
        res.json({ success: true, message: 'Appointment deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

module.exports = {
    getAppointments,
    getAppointment,
    createAppointment,
    updateAppointment,
    deleteAppointment
};
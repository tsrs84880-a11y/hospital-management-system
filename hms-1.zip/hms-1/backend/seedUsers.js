const mongoose = require('mongoose');
const User = require('./models/User');
require('dotenv').config();

// Connect to MongoDB
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/hospital_management', {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log('MongoDB Connected for seeding');
  } catch (error) {
    console.error('Database connection error:', error.message);
    process.exit(1);
  }
};

// Demo users data
const demoUsers = [
  {
    username: 'admin',
    password: 'admin123',
    role: 'admin',
    firstName: 'Admin',
    lastName: 'User',
    email: 'admin@hospital.com',
    phone: '+1234567890'
  },
  {
    username: 'doctor',
    password: 'doctor123',
    role: 'doctor',
    firstName: 'Dr. John',
    lastName: 'Smith',
    email: 'doctor@hospital.com',
    phone: '+1234567891',
    specialization: 'Cardiology',
    department: 'Cardiology'
  },
  {
    username: 'inventory',
    password: 'inventory123',
    role: 'inventory',
    firstName: 'Inventory',
    lastName: 'Manager',
    email: 'inventory@hospital.com',
    phone: '+1234567892'
  }
];

// Seed function
const seedUsers = async () => {
  try {
    await connectDB();
    
    // Clear existing users (optional)
    await User.deleteMany({});
    console.log('Cleared existing users');
    
    // Create demo users
    for (const userData of demoUsers) {
      const existingUser = await User.findOne({ username: userData.username });
      if (!existingUser) {
        const user = new User(userData);
        await user.save();
        console.log(`Created user: ${userData.username} (${userData.role})`);
      } else {
        console.log(`User ${userData.username} already exists`);
      }
    }
    
    console.log('Demo users seeded successfully!');
    process.exit(0);
  } catch (error) {
    console.error('Error seeding users:', error.message);
    process.exit(1);
  }
};

// Run the seed function
seedUsers();
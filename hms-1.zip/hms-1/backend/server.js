const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const http = require('http');
const socketIo = require('socket.io');
const connectDB = require('./config/database');

// Load env vars
dotenv.config();

// Connect to database
connectDB();

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: process.env.CLIENT_URL || 'http://localhost:3000',
    methods: ['GET', 'POST']
  }
});

// Make io accessible to our router
app.set('socketio', io);

// Body parser middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// Enable CORS
app.use(cors({
  origin: process.env.CLIENT_URL || 'http://localhost:3000',
  credentials: true
}));

// Socket.IO connection handling
io.on('connection', (socket) => {
  console.log('User connected:', socket.id);
  
  // Join room based on user role
  socket.on('join-room', (userData) => {
    socket.join(userData.role);
    socket.join(`user-${userData.userId}`);
    console.log(`User ${userData.userId} joined ${userData.role} room`);
  });
  
  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

// Route files
const auth = require('./routes/auth');
const patients = require('./routes/patients');
const doctors = require('./routes/doctors');
const appointments = require('./routes/appointments');
const inventory = require('./routes/inventory');

// Mount routers
app.use('/api/auth', auth);
app.use('/api/patients', patients);
app.use('/api/doctors', doctors);
app.use('/api/appointments', appointments);
app.use('/api/inventory', inventory);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!' });
});

// Handle 404
app.use('*', (req, res) => {
  res.status(404).json({ message: 'Route not found' });
});

const PORT = process.env.PORT || 5000;

server.listen(PORT, () => {
  console.log(`Server running in ${process.env.NODE_ENV || 'development'} mode on port ${PORT}`);
});
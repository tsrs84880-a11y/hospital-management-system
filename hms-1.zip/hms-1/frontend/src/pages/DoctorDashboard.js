import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import Sidebar from '../components/Sidebar';
import DoctorPatients from '../components/DoctorPatients';
import DoctorAppointments from '../components/DoctorAppointments';
import DoctorCalendar from '../components/DoctorCalendar';
import Dashboard from '../components/Dashboard';
import '../styles/DoctorDashboard.css';

const DoctorDashboard = () => {
  const [activeSection, setActiveSection] = useState('dashboard');
  const { user } = useAuth();

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'patients', label: 'My Patients', icon: '👥' },
    { id: 'appointments', label: 'Appointments', icon: '📅' },
    { id: 'schedule', label: 'Schedule', icon: '🗓️' }
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return <Dashboard userRole="doctor" />;
      case 'patients':
        return <DoctorPatients />;
      case 'appointments':
        return <DoctorAppointments />;
      case 'schedule':
        return <DoctorCalendar />;
      default:
        return <Dashboard userRole="doctor" />;
    }
  };

  return (
    <div className="doctor-dashboard">
      <Sidebar 
        menuItems={menuItems}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
        userRole="doctor"
      />
      <div className="main-content">
        <div className="content-header">
          <h1>Welcome, Dr. {user?.firstName} {user?.lastName}</h1>
          <p>Hospital Management System - Doctor Panel</p>
        </div>
        <div className="content-body">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default DoctorDashboard;
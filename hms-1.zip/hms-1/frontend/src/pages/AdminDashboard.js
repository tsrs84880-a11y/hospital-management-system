import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import Sidebar from '../components/Sidebar';
import PatientManagement from '../components/PatientManagement';
import DoctorManagement from '../components/DoctorManagement';
import InventoryManagement from '../components/InventoryManagement';
import AppointmentManagement from '../components/AppointmentManagement';
import Dashboard from '../components/Dashboard';
import '../styles/AdminDashboard.css';

const AdminDashboard = () => {
  const [activeSection, setActiveSection] = useState('dashboard');
  const { user } = useAuth();

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'patients', label: 'Patients', icon: '👥' },
    { id: 'doctors', label: 'Doctors', icon: '👨‍⚕️' },
    { id: 'appointments', label: 'Appointments', icon: '📅' },
    { id: 'inventory', label: 'Inventory', icon: '📦' }
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return <Dashboard />;
      case 'patients':
        return <PatientManagement />;
      case 'doctors':
        return <DoctorManagement />;
      case 'appointments':
        return <AppointmentManagement />;
      case 'inventory':
        return <InventoryManagement />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="admin-dashboard">
      <Sidebar 
        menuItems={menuItems}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
        userRole="admin"
      />
      <div className="dashboard-content">
        <div className="dashboard-header">
          <h1>Welcome, {user?.name || 'Admin'}</h1>
          <p>Hospital Management System - Admin Panel</p>
        </div>
        {renderContent()}
      </div>
    </div>
  );
};

export default AdminDashboard;
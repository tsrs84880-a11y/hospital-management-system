import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import Sidebar from '../components/Sidebar';
import InventoryManagement from '../components/InventoryManagement';
import InventoryStats from '../components/InventoryStats';
import '../styles/InventoryDashboard.css';

const InventoryDashboard = () => {
  const [activeSection, setActiveSection] = useState('dashboard');
  const { user } = useAuth();

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: '📊' },
    { id: 'inventory', label: 'Inventory', icon: '📦' }
  ];

  const renderContent = () => {
    switch (activeSection) {
      case 'dashboard':
        return <InventoryStats />;
      case 'inventory':
        return <InventoryManagement />;
      default:
        return <InventoryStats />;
    }
  };

  return (
    <div className="inventory-dashboard">
      <Sidebar 
        menuItems={menuItems}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
        userRole="inventory"
      />
      <div className="main-content">
        <div className="content-header">
          <h1>Welcome, {user?.name || 'Inventory Manager'}</h1>
          <p>Hospital Management System - Inventory Panel</p>
        </div>
        <div className="content-body">
          {renderContent()}
        </div>
      </div>
    </div>
  );
};

export default InventoryDashboard;
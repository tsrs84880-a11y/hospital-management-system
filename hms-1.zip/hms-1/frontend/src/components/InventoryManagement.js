import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import '../styles/InventoryManagement.css';

const InventoryManagement = ({ filter = 'all' }) => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  const [formData, setFormData] = useState({
    name: '',
    category: '',
    quantity: '',
    unit: '',
    price: '',
    supplier: '',
    expiryDate: '',
    minStockLevel: '',
    description: ''
  });
  const { getAuthHeader } = useAuth();

  useEffect(() => {
    fetchItems();
  }, [filter]);

  const fetchItems = async () => {
    try {
      let url = 'http://localhost:5000/api/inventory';
      if (filter === 'low-stock') {
        url += '?lowStock=true';
      }
      
      const response = await fetch(url, {
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeader()
        }
      });
      const data = await response.json();
      // Fix: Extract items array from response
      setItems(data.items || []);
    } catch (error) {
      console.error('Error fetching inventory items:', error);
      toast.error('Error fetching inventory items');
      setItems([]); // Set empty array on error
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const url = editingItem 
        ? `http://localhost:5000/api/inventory/${editingItem._id}`
        : 'http://localhost:5000/api/inventory';
      
      const method = editingItem ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeader()
        },
        body: JSON.stringify({
          // Fix: Map frontend fields to backend expected fields
          itemName: formData.name,
          category: formData.category,
          quantity: parseInt(formData.quantity),
          unit: formData.unit,
          unitPrice: parseFloat(formData.price),
          supplier: formData.supplier,
          expiryDate: formData.expiryDate,
          minStockLevel: parseInt(formData.minStockLevel),
          description: formData.description
        })
      });
  
      if (response.ok) {
        toast.success(editingItem ? 'Item updated successfully' : 'Item added successfully');
        fetchItems();
        resetForm();
      } else {
        const error = await response.json();
        console.error('Server error:', error);
        toast.error(error.message || 'Error saving item');
      }
    } catch (error) {
      console.error('Error saving item:', error);
      toast.error('Error saving item');
    }
  };

  const handleEdit = (item) => {
    setEditingItem(item);
    setFormData({
      // Fix: Map backend fields to frontend form fields
      name: item.itemName || '',
      category: item.category || '',
      quantity: item.quantity?.toString() || '',
      unit: item.unit || '',
      price: item.unitPrice?.toString() || '',
      supplier: item.supplier || '',
      expiryDate: item.expiryDate ? item.expiryDate.split('T')[0] : '',
      minStockLevel: item.minStockLevel?.toString() || '',
      description: item.description || ''
    });
    setShowModal(true);
  };

  const handleDelete = async (itemId) => {
    if (window.confirm('Are you sure you want to delete this item?')) {
      try {
        const response = await fetch(`http://localhost:5000/api/inventory/${itemId}`, {
          method: 'DELETE',
          headers: {
            ...getAuthHeader()
          }
        });

        if (response.ok) {
          toast.success('Item deleted successfully');
          fetchItems();
        } else {
          toast.error('Error deleting item');
        }
      } catch (error) {
        toast.error('Error deleting item');
      }
    }
  };

  const resetForm = () => {
    setFormData({
      name: '',
      category: '',
      quantity: '',
      unit: '',
      price: '',
      supplier: '',
      expiryDate: '',
      minStockLevel: '',
      description: ''
    });
    setEditingItem(null);
    setShowModal(false);
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const getStockStatus = (item) => {
    if (item.quantity <= item.minStockLevel) {
      return 'low';
    } else if (item.quantity <= item.minStockLevel * 2) {
      return 'medium';
    }
    return 'high';
  };

  const getStockBadge = (item) => {
    const status = getStockStatus(item);
    const statusText = {
      low: 'Low Stock',
      medium: 'Medium Stock',
      high: 'Good Stock'
    };
    return (
      <span className={`stock-badge ${status}`}>
        {statusText[status]}
      </span>
    );
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading inventory...</p>
      </div>
    );
  }

  return (
    <div className="inventory-management">
      <div className="inventory-header">
        <h2>{filter === 'low-stock' ? 'Low Stock Items' : 'Inventory Management'}</h2>
        <div className="header-actions">
          <button className="add-btn" onClick={() => setShowModal(true)}>
            + Add Item
          </button>
        </div>
      </div>

      {items.length === 0 ? (
        <div className="no-data">
          <p>{filter === 'low-stock' ? 'No low stock items' : 'No inventory items found'}</p>
        </div>
      ) : (
        <div className="inventory-table">
          <table>
            <thead>
              <tr>
                <th>Item Name</th>
                <th>Category</th>
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>Supplier</th>
                <th>Stock Status</th>
                <th>Expiry Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {items.map((item) => (
                <tr key={item._id}>
                  <td>
                    <div>
                      <strong>{item.itemName}</strong>
                      {item.description && (
                        <div style={{ fontSize: '12px', color: '#666', marginTop: '2px' }}>
                          {item.description}
                        </div>
                      )}
                    </div>
                  </td>
                  <td>
                    <span className="category-badge">{item.category}</span>
                  </td>
                  <td>
                    <div>
                      <strong>{item.quantity} {item.unit}</strong>
                      <div style={{ fontSize: '12px', color: '#666' }}>
                        Min: {item.minStockLevel}
                      </div>
                    </div>
                  </td>
                  <td>${item.unitPrice?.toFixed(2)}</td>
                  <td>{item.supplier || 'N/A'}</td>
                  <td>{getStockBadge(item)}</td>
                  <td>
                    {item.expiryDate ? (
                      new Date(item.expiryDate).toLocaleDateString()
                    ) : (
                      'N/A'
                    )}
                  </td>
                  <td>
                    <div className="action-buttons">
                      <button 
                        className="edit-btn"
                        onClick={() => handleEdit(item)}
                        title="Edit Item"
                      >
                        ✏️
                      </button>
                      <button 
                        className="delete-btn"
                        onClick={() => handleDelete(item._id)}
                        title="Delete Item"
                      >
                        🗑️
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>{editingItem ? 'Edit Item' : 'Add New Item'}</h3>
              <button className="close-btn" onClick={resetForm}>×</button>
            </div>
            <form onSubmit={handleSubmit} className="inventory-form">
              <div className="form-row">
                <div className="form-group">
                  <label>Item Name *</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Category *</label>
                  <select
                    name="category"
                    value={formData.category}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Category</option>
                    <option value="Medicine">Medicine</option>
                    <option value="Equipment">Equipment</option>
                    <option value="Supplies">Supplies</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Quantity *</label>
                  <input
                    type="number"
                    name="quantity"
                    value={formData.quantity}
                    onChange={handleChange}
                    required
                    min="0"
                  />
                </div>
                <div className="form-group">
                  <label>Unit *</label>
                  <input
                    type="text"
                    name="unit"
                    value={formData.unit}
                    onChange={handleChange}
                    required
                    placeholder="e.g., pieces, boxes, bottles"
                  />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Price *</label>
                  <input
                    type="number"
                    name="price"
                    value={formData.price}
                    onChange={handleChange}
                    required
                    min="0"
                    step="0.01"
                  />
                </div>
                <div className="form-group">
                  <label>Min Stock Level *</label>
                  <input
                    type="number"
                    name="minStockLevel"
                    value={formData.minStockLevel}
                    onChange={handleChange}
                    required
                    min="0"
                  />
                </div>
              </div>
              <div className="form-row">
                <div className="form-group">
                  <label>Supplier</label>
                  <input
                    type="text"
                    name="supplier"
                    value={formData.supplier}
                    onChange={handleChange}
                  />
                </div>
                <div className="form-group">
                  <label>Expiry Date</label>
                  <input
                    type="date"
                    name="expiryDate"
                    value={formData.expiryDate}
                    onChange={handleChange}
                  />
                </div>
              </div>
              <div className="form-group">
                <label>Description</label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  rows="3"
                ></textarea>
              </div>
              <div className="form-actions">
                <button type="button" onClick={resetForm} className="cancel-btn">
                  Cancel
                </button>
                <button type="submit" className="submit-btn">
                  {editingItem ? 'Update' : 'Add'} Item
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default InventoryManagement;
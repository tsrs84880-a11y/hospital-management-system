import React, { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from '../context/AuthContext';
import '../styles/AppointmentManagement.css';

const AppointmentManagement = () => {
    const [appointments, setAppointments] = useState([]);
    const [patients, setPatients] = useState([]);
    const [doctors, setDoctors] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showForm, setShowForm] = useState(false);
    const [editingAppointment, setEditingAppointment] = useState(null);
    const [filter, setFilter] = useState('all');
    const [socket, setSocket] = useState(null);
    const [notifications, setNotifications] = useState([]);
    const { user, getAuthHeader } = useAuth(); // Changed from getAuthHeaders to getAuthHeader
    const [formData, setFormData] = useState({
        patient: '',
        doctor: '',
        date: '',
        time: '',
        reason: '',
        status: 'scheduled'
    });

    useEffect(() => {
        fetchAppointments();
        fetchPatients();
        fetchDoctors();
        initializeSocket();

        return () => {
            if (socket) {
                socket.disconnect();
            }
        };
    }, []);

    const initializeSocket = () => {
        const newSocket = io('http://localhost:5000');

        newSocket.on('connect', () => {
            console.log('Connected to server');
            // Join room based on user role
            newSocket.emit('join-room', {
                userId: user?.id,
                role: user?.role
            });
        });

        newSocket.on('appointment-update', (data) => {
            handleRealTimeUpdate(data);
            showNotification(data);
        });

        setSocket(newSocket);
    };

    const handleRealTimeUpdate = (data) => {
        const { type, appointment } = data;

        setAppointments(prevAppointments => {
            switch (type) {
                case 'created':
                    // Check if appointment already exists to prevent duplicates
                    const exists = prevAppointments.some(apt => apt._id === appointment._id);
                    if (exists) {
                        return prevAppointments;
                    }
                    // Add new appointment at the beginning of the array
                    return [appointment, ...prevAppointments];
                case 'updated':
                    return prevAppointments.map(apt =>
                        apt._id === appointment._id ? appointment : apt
                    );
                case 'deleted':
                    return prevAppointments.filter(apt => apt._id !== appointment._id);
                default:
                    return prevAppointments;
            }
        });
    };

    const showNotification = (data) => {
        const { type, appointment } = data;
        let message = '';

        switch (type) {
            case 'created':
                message = `New appointment scheduled: ${appointment.patient.firstName} ${appointment.patient.lastName} with Dr. ${appointment.doctor.firstName} ${appointment.doctor.lastName}`;
                break;
            case 'updated':
                message = `Appointment updated: ${appointment.patient.firstName} ${appointment.patient.lastName} with Dr. ${appointment.doctor.firstName} ${appointment.doctor.lastName}`;
                break;
            case 'deleted':
                message = `Appointment cancelled: ${appointment.patient.firstName} ${appointment.patient.lastName} with Dr. ${appointment.doctor.firstName} ${appointment.doctor.lastName}`;
                break;
            default:
                return;
        }

        const notification = {
            id: Date.now(),
            message,
            type,
            timestamp: new Date()
        };

        setNotifications(prev => [notification, ...prev.slice(0, 4)]); // Keep only 5 notifications

        // Auto remove notification after 5 seconds
        setTimeout(() => {
            setNotifications(prev => prev.filter(n => n.id !== notification.id));
        }, 5000);
    };

    const fetchAppointments = async () => {
        try {
            const response = await fetch('http://localhost:5000/api/appointments', {
                headers: getAuthHeader() // Changed from getAuthHeaders() to getAuthHeader()
            });
            const data = await response.json();
            if (data.success) {
                setAppointments(data.data);
            }
        } catch (error) {
            console.error('Error fetching appointments:', error);
        } finally {
            setLoading(false);
        }
    };

    const fetchPatients = async () => {
        try {
            console.log('Fetching patients...');
            const response = await fetch('http://localhost:5000/api/patients', {
                headers: getAuthHeader() // Changed from getAuthHeaders() to getAuthHeader()
            });
            const data = await response.json();
            console.log('Patients API response:', data);
            if (data.success) {
                console.log('Setting patients:', data.patients);
                setPatients(data.patients);
            } else {
                console.log('API returned success: false');
            }
        } catch (error) {
            console.error('Error fetching patients:', error);
        }
    };

    const fetchDoctors = async () => {
        try {
            console.log('Fetching doctors...');
            const response = await fetch('http://localhost:5000/api/doctors', {
                headers: getAuthHeader() // Changed from getAuthHeaders() to getAuthHeader()
            });
            const data = await response.json();
            console.log('Doctors API response:', data);
            if (data.success) {
                console.log('Setting doctors:', data.doctors);
                setDoctors(data.doctors);
            } else {
                console.log('API returned success: false');
            }
        } catch (error) {
            console.error('Error fetching doctors:', error);
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const url = editingAppointment
                ? `http://localhost:5000/api/appointments/${editingAppointment._id}`
                : 'http://localhost:5000/api/appointments';
    
            const method = editingAppointment ? 'PUT' : 'POST';
    
            // Map frontend field names to backend expected field names
            const appointmentData = {
                patient: formData.patient,
                doctor: formData.doctor,
                appointmentDate: formData.date, // Map 'date' to 'appointmentDate'
                appointmentTime: formData.time, // Map 'time' to 'appointmentTime'
                reason: formData.reason,
                status: formData.status
            };
    
            const response = await fetch(url, {
                method,
                headers: {
                    'Content-Type': 'application/json',
                    ...getAuthHeader()
                },
                body: JSON.stringify(appointmentData) // Send mapped data instead of formData
            });
    
            const data = await response.json();
            if (data.success) {
                resetForm();
                setShowForm(false); // Close the form after successful submission
                // Real-time update will handle the appointment list refresh
            } else {
                alert(data.message || 'Operation failed');
            }
        } catch (error) {
            console.error('Error saving appointment:', error);
            alert('Error saving appointment');
        }
    };

    const handleEdit = (appointment) => {
        setEditingAppointment(appointment);
        setFormData({
            patient: appointment.patient._id,
            doctor: appointment.doctor._id,
            date: appointment.appointmentDate.split('T')[0],
            time: appointment.appointmentTime,
            reason: appointment.reason,
            status: appointment.status
        });
        setShowForm(true);
    };

    const handleDelete = async (id) => {
        if (window.confirm('Are you sure you want to delete this appointment?')) {
            try {
                const response = await fetch(`http://localhost:5000/api/appointments/${id}`, {
                    method: 'DELETE',
                    headers: getAuthHeader() // Changed from getAuthHeaders() to getAuthHeader()
                });

                const data = await response.json();
                if (!data.success) {
                    alert(data.message || 'Delete failed');
                }
                // No need to manually update appointments - real-time update will handle it
            } catch (error) {
                console.error('Error deleting appointment:', error);
                alert('Error deleting appointment');
            }
        }
    };

    const resetForm = () => {
        setFormData({
            patient: '',
            doctor: '',
            date: '',
            time: '',
            reason: '',
            status: 'scheduled'
        });
        setEditingAppointment(null);
        setShowForm(false);
    };

    const handleInputChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const filteredAppointments = appointments.filter(appointment => {
        if (filter === 'all') return true;
        return appointment.status === filter;
    });

    const getStatusColor = (status) => {
        switch (status) {
            case 'scheduled': return '#007bff';
            case 'completed': return '#28a745';
            case 'cancelled': return '#dc3545';
            case 'in-progress': return '#ffc107';
            default: return '#6c757d';
        }
    };

    if (loading) {
        return <div className="loading">Loading appointments...</div>;
    }

    return (
        <div className="appointment-management">
            {/* Real-time Notifications */}
            {notifications.length > 0 && (
                <div className="notifications">
                    {notifications.map(notification => (
                        <div key={notification.id} className={`notification notification-${notification.type}`}>
                            <span className="notification-message">{notification.message}</span>
                            <span className="notification-time">
                                {notification.timestamp.toLocaleTimeString()}
                            </span>
                        </div>
                    ))}
                </div>
            )}

            <div className="appointment-header">
                <h2>Appointment Management</h2>
                <div className="header-actions">
                    <select
                        value={filter}
                        onChange={(e) => setFilter(e.target.value)}
                        className="filter-select"
                    >
                        <option value="all">All Appointments</option>
                        <option value="scheduled">Scheduled</option>
                        <option value="completed">Completed</option>
                        <option value="cancelled">Cancelled</option>
                        <option value="in-progress">In Progress</option>
                    </select>
                    <button
                        className="btn btn-primary"
                        onClick={() => setShowForm(!showForm)}
                    >
                        {showForm ? 'Cancel' : 'Schedule New Appointment'}
                    </button>
                </div>
            </div>

            {showForm && (
                <div className="appointment-form-overlay">
                    <div className="appointment-form-modal">
                        <div className="form-header">
                            <h3>
                                <i className="fas fa-calendar-plus"></i>
                                {editingAppointment ? 'Edit Appointment' : 'Schedule New Appointment'}
                            </h3>
                            <button
                                type="button"
                                className="close-btn"
                                onClick={resetForm}
                            >
                                <i className="fas fa-times"></i>
                            </button>
                        </div>

                        <form onSubmit={handleSubmit} className="appointment-form">
                            {/* Patient Information Section */}
                            <div className="form-section">
                                <div className="section-header">
                                    <i className="fas fa-user"></i>
                                    <h4>Patient Information</h4>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="patient">
                                        <i className="fas fa-user-injured"></i>
                                        Select Patient *
                                    </label>
                                    <div className="select-wrapper">
                                        <select
                                            id="patient"
                                            name="patient"
                                            value={formData.patient}
                                            onChange={handleInputChange}
                                            required
                                            className="form-select"
                                        >
                                            <option value="">Choose a patient...</option>
                                            {patients.map(patient => (
                                                <option key={patient._id} value={patient._id}>
                                                    {patient.firstName} {patient.lastName} - ID: {patient.patientId}
                                                </option>
                                            ))}
                                        </select>
                                        <i className="fas fa-chevron-down select-arrow"></i>
                                    </div>
                                    {patients.length === 0 && (
                                        <p className="form-hint">
                                            <i className="fas fa-info-circle"></i>
                                            No patients registered yet. Please register patients first.
                                        </p>
                                    )}
                                </div>
                            </div>

                            {/* Doctor Selection Section */}
                            <div className="form-section">
                                <div className="section-header">
                                    <i className="fas fa-user-md"></i>
                                    <h4>Doctor Assignment</h4>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="doctor">
                                        <i className="fas fa-stethoscope"></i>
                                        Select Doctor *
                                    </label>
                                    <div className="select-wrapper">
                                        <select
                                            id="doctor"
                                            name="doctor"
                                            value={formData.doctor}
                                            onChange={handleInputChange}
                                            required
                                            className="form-select"
                                        >
                                            <option value="">Choose a doctor...</option>
                                            {doctors.map(doctor => (
                                                <option key={doctor._id} value={doctor._id}>
                                                    Dr. {doctor.firstName} {doctor.lastName} - {doctor.specialization}
                                                </option>
                                            ))}
                                        </select>
                                        <i className="fas fa-chevron-down select-arrow"></i>
                                    </div>
                                    {doctors.length === 0 && (
                                        <p className="form-hint">
                                            <i className="fas fa-info-circle"></i>
                                            No doctors registered yet. Please register doctors first.
                                        </p>
                                    )}
                                </div>
                            </div>

                            {/* Schedule Section */}
                            <div className="form-section">
                                <div className="section-header">
                                    <i className="fas fa-clock"></i>
                                    <h4>Schedule Details</h4>
                                </div>
                                <div className="form-row">
                                    <div className="form-group">
                                        <label htmlFor="date">
                                            <i className="fas fa-calendar-alt"></i>
                                            Appointment Date *
                                        </label>
                                        <input
                                            id="date"
                                            type="date"
                                            name="date"
                                            value={formData.date}
                                            onChange={handleInputChange}
                                            min={new Date().toISOString().split('T')[0]}
                                            required
                                            className="form-input"
                                        />
                                    </div>

                                    <div className="form-group">
                                        <label htmlFor="time">
                                            <i className="fas fa-clock"></i>
                                            Appointment Time *
                                        </label>
                                        <input
                                            id="time"
                                            type="time"
                                            name="time"
                                            value={formData.time}
                                            onChange={handleInputChange}
                                            required
                                            className="form-input"
                                        />
                                    </div>
                                </div>
                            </div>

                            {/* Additional Details Section */}
                            <div className="form-section">
                                <div className="section-header">
                                    <i className="fas fa-notes-medical"></i>
                                    <h4>Additional Details</h4>
                                </div>

                                <div className="form-group">
                                    <label htmlFor="reason">
                                        <i className="fas fa-clipboard-list"></i>
                                        Reason for Visit *
                                    </label>
                                    <textarea
                                        id="reason"
                                        name="reason"
                                        value={formData.reason}
                                        onChange={handleInputChange}
                                        rows="4"
                                        required
                                        className="form-textarea"
                                        placeholder="Please describe the reason for this appointment..."
                                    />
                                </div>

                                <div className="form-group">
                                    <label htmlFor="status">
                                        <i className="fas fa-flag"></i>
                                        Appointment Status *
                                    </label>
                                    <div className="select-wrapper">
                                        <select
                                            id="status"
                                            name="status"
                                            value={formData.status}
                                            onChange={handleInputChange}
                                            required
                                            className="form-select"
                                        >
                                            <option value="scheduled">Scheduled</option>
                                            <option value="completed">Completed</option>
                                            <option value="cancelled">Cancelled</option>
                                            <option value="in-progress">In Progress</option>
                                        </select>
                                        <i className="fas fa-chevron-down select-arrow"></i>
                                    </div>
                                </div>
                            </div>

                            {/* Form Actions */}
                            <div className="form-actions">
                                <button type="button" className="btn btn-secondary" onClick={resetForm}>
                                    <i className="fas fa-times"></i>
                                    Cancel
                                </button>
                                <button type="submit" className="btn btn-primary">
                                    <i className="fas fa-save"></i>
                                    {editingAppointment ? 'Update Appointment' : 'Schedule Appointment'}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            <div className="appointments-table">
                <table>
                    <thead>
                        <tr>
                            <th>Appointment ID</th>
                            <th>Patient</th>
                            <th>Doctor</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Reason</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {filteredAppointments.map(appointment => (
                            <tr key={appointment._id}>
                                <td>{appointment.appointmentId}</td>
                                <td>{appointment.patient.firstName} {appointment.patient.lastName}</td>
                                <td>Dr. {appointment.doctor.firstName} {appointment.doctor.lastName}</td>
                                <td>{new Date(appointment.appointmentDate).toLocaleDateString()}</td>
                                <td>{appointment.appointmentTime}</td>
                                <td>{appointment.reason}</td>
                                <td>
                                    <span
                                        className="status-badge"
                                        style={{ backgroundColor: getStatusColor(appointment.status) }}
                                    >
                                        {appointment.status}
                                    </span>
                                </td>
                                <td>
                                    <button
                                        className="btn btn-edit"
                                        onClick={() => handleEdit(appointment)}
                                    >
                                        Edit
                                    </button>
                                    <button
                                        className="btn btn-delete"
                                        onClick={() => handleDelete(appointment._id)}
                                    >
                                        Delete
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

export default AppointmentManagement;
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import '../styles/DoctorPatients.css';

const DoctorPatients = () => {
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedPatient, setSelectedPatient] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [showRegisterModal, setShowRegisterModal] = useState(false);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    dateOfBirth: '',
    gender: '',
    patientType: '',
    disease: '',
    phone: '',
    email: '',
    address: '',
    emergencyContact: '',
    medicalHistory: ''
  });
  const { getAuthHeader, user } = useAuth(); // Add user to get doctor ID

  useEffect(() => {
    fetchPatients();
  }, []);

  const fetchPatients = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/patients', {
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeader()
        }
      });
      const data = await response.json();
      // Fix: Extract the patients array from the nested response structure
      setPatients(data.success && data.patients ? data.patients : []);
    } catch (error) {
      toast.error('Error fetching patients');
      setPatients([]); // Set empty array on error
    } finally {
      setLoading(false);
    }
  };

  const viewPatientDetails = (patient) => {
    setSelectedPatient(patient);
    setShowModal(true);
  };

  const bookAppointment = async (patientId) => {
    try {
      // Validate that we have a user and patient ID
      if (!user || !user.id) {
        toast.error('User not authenticated');
        return;
      }
      
      if (!patientId) {
        toast.error('Patient ID is required');
        return;
      }
  
      // Get tomorrow's date and format as ISO8601
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      tomorrow.setHours(10, 0, 0, 0); // Set to 10:00 AM
  
      const appointmentData = {
        patient: patientId,
        doctor: user.id,
        appointmentDate: tomorrow.toISOString(), // Full ISO8601 format
        appointmentTime: '10:00',
        reason: 'Follow-up consultation'
        // Removed status field - backend will set default
      };
  
      console.log('Booking appointment with data:', appointmentData);
  
      const response = await fetch('http://localhost:5000/api/appointments', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeader()
        },
        body: JSON.stringify(appointmentData)
      });
  
      const responseData = await response.json();
      console.log('Server response:', responseData);
  
      if (response.ok) {
        toast.success('Appointment booked successfully');
      } else {
        console.error('Appointment booking error:', responseData);
        if (responseData.errors && Array.isArray(responseData.errors)) {
          const errorMessages = responseData.errors.map(err => err.msg).join(', ');
          toast.error(`Validation errors: ${errorMessages}`);
        } else {
          toast.error(responseData.message || 'Error booking appointment');
        }
      }
    } catch (error) {
      console.error('Network error:', error);
      toast.error('Network error: Unable to book appointment');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleRegisterPatient = async (e) => {
    e.preventDefault();
    try {
      // Calculate age from date of birth
      const calculateAge = (dateOfBirth) => {
        const today = new Date();
        const birthDate = new Date(dateOfBirth);
        let age = today.getFullYear() - birthDate.getFullYear();
        const monthDiff = today.getMonth() - birthDate.getMonth();
        
        if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
          age--;
        }
        
        return age;
      };
  
      const age = calculateAge(formData.dateOfBirth);
  
      const response = await fetch('http://localhost:5000/api/patients', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeader()
        },
        body: JSON.stringify({
          ...formData,
          name: `${formData.firstName} ${formData.lastName}`,
          age: age // Add the calculated age
        })
      });
  
      if (response.ok) {
        toast.success('Patient registered successfully');
        setShowRegisterModal(false);
        setFormData({
          firstName: '',
          lastName: '',
          dateOfBirth: '',
          gender: '',
          patientType: '',
          disease: '',
          phone: '',
          email: '',
          address: '',
          emergencyContact: '',
          medicalHistory: ''
        });
        fetchPatients(); // Refresh the patients list
      } else {
        const error = await response.json();
        console.error('Registration error:', error); // Add logging for debugging
        if (error.errors && Array.isArray(error.errors)) {
          // Handle validation errors
          const errorMessages = error.errors.map(err => err.msg).join(', ');
          toast.error(`Validation errors: ${errorMessages}`);
        } else {
          toast.error(error.message || 'Error registering patient');
        }
      }
    } catch (error) {
      console.error('Network error:', error); // Add logging for debugging
      toast.error('Network error: Unable to register patient');
    }
  };

  return (
    <div className="doctor-patients">
      <div className="section-header">
        <h2>My Patients</h2>
        <div className="header-actions">
          <p>Manage your registered patients</p>
          <button 
            className="register-patient-btn"
            onClick={() => setShowRegisterModal(true)}
          >
            <i className="fas fa-plus"></i>
            Register New Patient
          </button>
        </div>
      </div>

      <div className="patients-grid">
        {patients.map((patient) => (
          <div key={patient._id} className="patient-card">
            <div className="patient-info">
              <div className="patient-avatar">
                {patient.name.charAt(0).toUpperCase()}
              </div>
              <div className="patient-details">
                <h3>{patient.name}</h3>
                <p className="patient-id">ID: {patient.patientId}</p>
                <p className="patient-contact">{patient.phone}</p>
                <p className="patient-gender">{patient.gender}</p>
              </div>
            </div>
            <div className="patient-actions">
              <button 
                className="view-btn"
                onClick={() => viewPatientDetails(patient)}
              >
                View Details
              </button>
              <button 
                className="appointment-btn"
                onClick={() => bookAppointment(patient._id)}
              >
                Book Appointment
              </button>
            </div>
          </div>
        ))}
      </div>

      {patients.length === 0 && (
        <div className="no-data">
          <p>No patients assigned yet</p>
        </div>
      )}

      {showModal && selectedPatient && (
        <div className="modal-overlay">
          <div className="modal patient-details-modal">
            <div className="modal-header">
              <h3>Patient Details</h3>
              <button className="close-btn" onClick={() => setShowModal(false)}>×</button>
            </div>
            <div className="patient-details-content">
              <div className="detail-row">
                <label>Name:</label>
                <span>{selectedPatient.name}</span>
              </div>
              <div className="detail-row">
                <label>Patient ID:</label>
                <span>{selectedPatient.patientId}</span>
              </div>
              <div className="detail-row">
                <label>Email:</label>
                <span>{selectedPatient.email}</span>
              </div>
              <div className="detail-row">
                <label>Phone:</label>
                <span>{selectedPatient.phone}</span>
              </div>
              <div className="detail-row">
                <label>Gender:</label>
                <span>{selectedPatient.gender}</span>
              </div>
              <div className="detail-row">
                <label>Date of Birth:</label>
                <span>{selectedPatient.dateOfBirth ? new Date(selectedPatient.dateOfBirth).toLocaleDateString() : 'Not provided'}</span>
              </div>
              <div className="detail-row">
                <label>Address:</label>
                <span>{selectedPatient.address || 'Not provided'}</span>
              </div>
              <div className="detail-row">
                <label>Emergency Contact:</label>
                <span>{selectedPatient.emergencyContact || 'Not provided'}</span>
              </div>
              <div className="detail-row">
                <label>Medical History:</label>
                <span>{selectedPatient.medicalHistory || 'No medical history recorded'}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {showRegisterModal && (
        <div className="modal-overlay">
          <div className="modal register-patient-modal">
            <div className="modal-header">
              <h3>Register New Patient</h3>
              <button className="close-btn" onClick={() => setShowRegisterModal(false)}>×</button>
            </div>
            <form onSubmit={handleRegisterPatient} className="register-form">
              <div className="form-row">
                <div className="form-group">
                  <label>First Name *</label>
                  <input
                    type="text"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Last Name *</label>
                  <input
                    type="text"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label>Date of Birth *</label>
                  <input
                    type="date"
                    name="dateOfBirth"
                    value={formData.dateOfBirth}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Gender *</label>
                  <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Patient Type *</label>
                  <select
                    name="patientType"
                    value={formData.patientType}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Select Type</option>
                    <option value="inpatient">Inpatient</option>
                    <option value="outpatient">Outpatient</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Disease/Condition *</label>
                  <input
                    type="text"
                    name="disease"
                    value={formData.disease}
                    onChange={handleInputChange}
                    placeholder="e.g., Hypertension, Diabetes"
                    required
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Phone *</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Email *</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <label>Address</label>
                <textarea
                  name="address"
                  value={formData.address}
                  onChange={handleInputChange}
                  rows="2"
                  placeholder="Patient's address"
                ></textarea>
              </div>

              <div className="form-group">
                <label>Emergency Contact</label>
                <input
                  type="tel"
                  name="emergencyContact"
                  value={formData.emergencyContact}
                  onChange={handleInputChange}
                  placeholder="Emergency contact number"
                />
              </div>

              <div className="form-group">
                <label>Medical History</label>
                <textarea
                  name="medicalHistory"
                  value={formData.medicalHistory}
                  onChange={handleInputChange}
                  rows="3"
                  placeholder="Previous medical conditions, allergies, etc."
                ></textarea>
              </div>

              <div className="form-actions">
                <button type="button" onClick={() => setShowRegisterModal(false)} className="cancel-btn">
                  Cancel
                </button>
                <button type="submit" className="submit-btn">
                  Register Patient
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default DoctorPatients;
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import '../styles/Sidebar.css';

const Sidebar = ({ menuItems, activeSection, setActiveSection, userRole }) => {
  const { logout, user } = useAuth();
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [isMobile, setIsMobile] = useState(false);

  const handleLogout = () => {
    logout();
  };

  // Check if device is mobile
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth <= 767);
      if (window.innerWidth > 767) {
        setIsMobileOpen(false);
      }
    };
    
    checkMobile();
    window.addEventListener('resize', checkMobile);
    return () => window.removeEventListener('resize', checkMobile);
  }, []);

  const toggleSidebar = () => {
    if (isMobile) {
      setIsMobileOpen(!isMobileOpen);
    } else {
      setIsCollapsed(!isCollapsed);
    }
  };

  // Get user display name
  const getUserName = () => {
    if (user?.firstName && user?.lastName) {
      return `${user.firstName} ${user.lastName}`;
    }
    return user?.username || 'User';
  };

  return (
    <>
      {/* Mobile overlay */}
      {isMobile && isMobileOpen && (
        <div 
          className="mobile-overlay" 
          onClick={() => setIsMobileOpen(false)}
        />
      )}
      
      <div className={`sidebar ${
        isCollapsed && !isMobile ? 'collapsed' : ''
      } ${
        isMobile && isMobileOpen ? 'open' : ''
      }`}>
      <div className="sidebar-header">
        <button className="hamburger-btn" onClick={toggleSidebar}>
          <span className="hamburger-icon">
            {isMobile ? (isMobileOpen ? '✕' : '☰') : (isCollapsed ? '☰' : '✕')}
          </span>
        </button>
        
        {(!isCollapsed || isMobile) && (
          <>
            <div className="logo">
              <h2>🏥 HMS</h2>
            </div>
            <div className="user-info">
              <div className="user-avatar">
                {getUserName().charAt(0).toUpperCase()}
              </div>
              <div className="user-details">
                <p className="user-name">{getUserName()}</p>
                <p className="user-role">{userRole.charAt(0).toUpperCase() + userRole.slice(1)}</p>
              </div>
            </div>
          </>
        )}
        
        {isCollapsed && !isMobile && (
          <div className="collapsed-logo">
            <span className="logo-icon">🏥</span>
          </div>
        )}
      </div>
      
      <nav className="sidebar-nav">
        <ul>
          {menuItems.map((item) => (
            <li key={item.id}>
              <button
                className={`nav-item ${activeSection === item.id ? 'active' : ''}`}
                onClick={() => setActiveSection(item.id)}
                title={isCollapsed && !isMobile ? item.label : ''}
              >
                <span className="nav-icon">{item.icon}</span>
                {(!isCollapsed || isMobile) && <span className="nav-label">{item.label}</span>}
              </button>
            </li>
          ))}
        </ul>
      </nav>
      
      <div className="sidebar-footer">
        <button 
          className="logout-btn" 
          onClick={handleLogout}
          title={isCollapsed && !isMobile ? 'Logout' : ''}
        >
          <span className="nav-icon">🚪</span>
          {(!isCollapsed || isMobile) && <span className="nav-label">Logout</span>}
        </button>
      </div>
      </div>
    </>
  );
};

export default Sidebar;
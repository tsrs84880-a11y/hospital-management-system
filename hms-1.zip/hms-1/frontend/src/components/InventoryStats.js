import React, { useState, useEffect } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from '../context/AuthContext';
import '../styles/InventoryStats.css';

const InventoryStats = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [socket, setSocket] = useState(null);
  const [notifications, setNotifications] = useState([]);
  const { user } = useAuth();

  useEffect(() => {
    fetchStats();
    initializeSocket();

    return () => {
      if (socket) {
        socket.disconnect();
      }
    };
  }, []);

  const initializeSocket = () => {
    const newSocket = io('http://localhost:5000');

    newSocket.on('connect', () => {
      console.log('Connected to server for inventory updates');
      // Join inventory room for real-time updates
      newSocket.emit('join-room', {
        userId: user?.id,
        role: 'inventory'
      });
    });

    newSocket.on('inventory-update', (data) => {
      handleRealTimeUpdate(data);
      showNotification(data);
    });

    newSocket.on('inventory-stats-update', (data) => {
      if (data.success) {
        setStats(data.stats); // Fixed: use data.stats instead of data.data
        showNotification({
          type: 'stats-update',
          message: 'Inventory statistics updated'
        });
      }
    });

    setSocket(newSocket);
  };

  const handleRealTimeUpdate = (data) => {
    // Refresh stats when inventory changes
    fetchStats();
  };

  const showNotification = (data) => {
    const notification = {
      id: Date.now(),
      message: data.message || `Inventory ${data.type}`,
      type: data.type || 'update',
      timestamp: new Date()
    };

    setNotifications(prev => [notification, ...prev.slice(0, 4)]); // Keep last 5 notifications

    // Auto remove notification after 5 seconds
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== notification.id));
    }, 5000);
  };

  const fetchStats = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:5000/api/inventory/stats', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      const data = await response.json();
      console.log('API Response:', data); // Debug log
      if (data.success) {
        setStats(data.stats); // Fixed: use data.stats instead of data.data
      }
    } catch (error) {
      console.error('Error fetching inventory stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading inventory statistics...</p>
      </div>
    );
  }

  if (!stats) {
    return (
      <div className="error-container">
        <div className="error-icon">⚠️</div>
        <p>Failed to load inventory statistics</p>
        <button onClick={fetchStats} className="retry-btn">Retry</button>
      </div>
    );
  }

  return (
    <div className="inventory-stats">
      {/* Real-time Notifications */}
      {notifications.length > 0 && (
        <div className="notifications-container">
          {notifications.map(notification => (
            <div key={notification.id} className={`notification ${notification.type}`}>
              <span className="notification-icon">
                {notification.type === 'update' ? '🔄' : 
                 notification.type === 'add' ? '➕' : 
                 notification.type === 'delete' ? '🗑️' : '📊'}
              </span>
              <span className="notification-message">{notification.message}</span>
              <span className="notification-time">
                {notification.timestamp.toLocaleTimeString()}
              </span>
            </div>
          ))}
        </div>
      )}

      <div className="stats-header">
        <h2>Real-time Inventory Statistics</h2>
        <div className="live-indicator">
          <span className="live-dot"></span>
          <span>Live</span>
        </div>
      </div>
      
      <div className="stats-grid">
        <div className="stat-card total">
          <div className="stat-icon">📦</div>
          <div className="stat-content">
            <h3>Total Items</h3>
            <p className="stat-number">{stats.totalItems}</p>
            <span className="stat-label">Items in inventory</span>
          </div>
        </div>

        <div className="stat-card low-stock">
          <div className="stat-icon">⚠️</div>
          <div className="stat-content">
            <h3>Low Stock Items</h3>
            <p className="stat-number">{stats.lowStockItems}</p>
            <span className="stat-label">Needs restocking</span>
          </div>
        </div>

        <div className="stat-card expiring">
          <div className="stat-icon">⏰</div>
          <div className="stat-content">
            <h3>Expiring Soon</h3>
            <p className="stat-number">{stats.expiringSoon}</p>
            <span className="stat-label">Within 30 days</span>
          </div>
        </div>

        <div className="stat-card categories">
          <div className="stat-icon">📊</div>
          <div className="stat-content">
            <h3>Categories</h3>
            <p className="stat-number">{stats.categoryStats?.length || 0}</p>
            <span className="stat-label">Active categories</span>
          </div>
        </div>
      </div>

      <div className="category-breakdown">
        <h3>Category Breakdown</h3>
        <div className="category-grid">
          {stats.categoryStats?.map((category, index) => (
            <div key={index} className="category-card">
              <div className="category-header">
                <h4>{category._id}</h4>
                <span className="category-count">{category.count}</span>
              </div>
              <p className="category-items">{category.count} items</p>
              <div className="category-bar">
                <div 
                  className="category-fill"
                  style={{ 
                    width: `${(category.count / stats.totalItems) * 100}%` 
                  }}
                ></div>
              </div>
              <span className="category-percentage">
                {((category.count / stats.totalItems) * 100).toFixed(1)}%
              </span>
            </div>
          )) || (
            <div className="no-categories">
              <p>No categories found</p>
            </div>
          )}
        </div>
      </div>

      <div className="stats-footer">
        <p className="last-updated">
          Last updated: {new Date().toLocaleString()}
        </p>
        <button onClick={fetchStats} className="refresh-btn">
          🔄 Refresh
        </button>
      </div>
    </div>
  );
};

export default InventoryStats;
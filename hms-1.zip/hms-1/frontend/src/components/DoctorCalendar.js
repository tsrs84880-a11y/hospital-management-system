import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import '../styles/DoctorCalendar.css';

const DoctorCalendar = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [selectedDate, setSelectedDate] = useState(null);
  const [dayAppointments, setDayAppointments] = useState([]);
  const { getAuthHeader, user } = useAuth();

  useEffect(() => {
    fetchAppointments();
  }, [currentDate]);

  const fetchAppointments = async () => {
    try {
      setLoading(true);
      const response = await fetch('http://localhost:5000/api/appointments', {
        headers: getAuthHeader()
      });
      const data = await response.json();
      if (data.success) {
        setAppointments(data.data);
      }
    } catch (error) {
      console.error('Error fetching appointments:', error);
      toast.error('Failed to load appointments');
    } finally {
      setLoading(false);
    }
  };

  const getDaysInMonth = (date) => {
    const year = date.getFullYear();
    const month = date.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDayOfWeek = firstDay.getDay();

    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDayOfWeek; i++) {
      days.push(null);
    }
    
    // Add all days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      days.push(new Date(year, month, day));
    }
    
    return days;
  };

  const getAppointmentsForDate = (date) => {
    if (!date) return [];
    return appointments.filter(appointment => {
      const appointmentDate = new Date(appointment.appointmentDate);
      return appointmentDate.toDateString() === date.toDateString();
    });
  };

  const handleDateClick = (date) => {
    if (!date) return;
    setSelectedDate(date);
    const dayAppts = getAppointmentsForDate(date);
    setDayAppointments(dayAppts);
  };

  const navigateMonth = (direction) => {
    const newDate = new Date(currentDate);
    newDate.setMonth(currentDate.getMonth() + direction);
    setCurrentDate(newDate);
    setSelectedDate(null);
    setDayAppointments([]);
  };

  const formatTime = (timeString) => {
    const [hours, minutes] = timeString.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour % 12 || 12;
    return `${displayHour}:${minutes} ${ampm}`;
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'scheduled': return '#2196F3';
      case 'completed': return '#4CAF50';
      case 'cancelled': return '#f44336';
      case 'in-progress': return '#FF9800';
      default: return '#9E9E9E';
    }
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  if (loading) {
    return (
      <div className="calendar-loading">
        <div className="loading-spinner"></div>
        <p>Loading calendar...</p>
      </div>
    );
  }

  return (
    <div className="doctor-calendar">
      <div className="calendar-header">
        <h2>My Schedule</h2>
        <div className="calendar-navigation">
          <button 
            className="nav-btn" 
            onClick={() => navigateMonth(-1)}
            aria-label="Previous month"
          >
            ‹
          </button>
          <h3 className="current-month">
            {monthNames[currentDate.getMonth()]} {currentDate.getFullYear()}
          </h3>
          <button 
            className="nav-btn" 
            onClick={() => navigateMonth(1)}
            aria-label="Next month"
          >
            ›
          </button>
        </div>
      </div>

      <div className="calendar-container">
        <div className="calendar-grid">
          {/* Day headers */}
          {dayNames.map(day => (
            <div key={day} className="day-header">
              {day}
            </div>
          ))}
          
          {/* Calendar days */}
          {getDaysInMonth(currentDate).map((date, index) => {
            const dayAppointments = date ? getAppointmentsForDate(date) : [];
            const isToday = date && date.toDateString() === new Date().toDateString();
            const isSelected = selectedDate && date && date.toDateString() === selectedDate.toDateString();
            
            return (
              <div 
                key={index} 
                className={`calendar-day ${
                  date ? 'valid-day' : 'empty-day'
                } ${
                  isToday ? 'today' : ''
                } ${
                  isSelected ? 'selected' : ''
                } ${
                  dayAppointments.length > 0 ? 'has-appointments' : ''
                }`}
                onClick={() => handleDateClick(date)}
              >
                {date && (
                  <>
                    <span className="day-number">{date.getDate()}</span>
                    {dayAppointments.length > 0 && (
                      <div className="appointment-indicators">
                        {dayAppointments.slice(0, 3).map((apt, idx) => (
                          <div 
                            key={idx} 
                            className="appointment-dot"
                            style={{ backgroundColor: getStatusColor(apt.status) }}
                            title={`${apt.patientId?.firstName || 'Patient'} - ${formatTime(apt.appointmentTime)}`}
                          ></div>
                        ))}
                        {dayAppointments.length > 3 && (
                          <span className="more-appointments">+{dayAppointments.length - 3}</span>
                        )}
                      </div>
                    )}
                  </>
                )}
              </div>
            );
          })}
        </div>

        {/* Selected day details */}
        {selectedDate && (
          <div className="day-details">
            <h4>
              Appointments for {selectedDate.toLocaleDateString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric'
              })}
            </h4>
            
            {dayAppointments.length === 0 ? (
              <p className="no-appointments">No appointments scheduled for this day.</p>
            ) : (
              <div className="day-appointments">
                {dayAppointments.map((appointment) => (
                  <div key={appointment._id} className="appointment-item">
                    <div className="appointment-time">
                      {formatTime(appointment.appointmentTime)}
                    </div>
                    <div className="appointment-info">
                      <div className="patient-name">
                        {appointment.patientId?.firstName} {appointment.patientId?.lastName}
                      </div>
                      <div className="appointment-reason">{appointment.reason}</div>
                      <div 
                        className="appointment-status-badge"
                        style={{ backgroundColor: getStatusColor(appointment.status) }}
                      >
                        {appointment.status}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Legend */}
      <div className="calendar-legend">
        <h5>Status Legend:</h5>
        <div className="legend-items">
          <div className="legend-item">
            <div className="legend-dot" style={{ backgroundColor: '#2196F3' }}></div>
            <span>Scheduled</span>
          </div>
          <div className="legend-item">
            <div className="legend-dot" style={{ backgroundColor: '#FF9800' }}></div>
            <span>In Progress</span>
          </div>
          <div className="legend-item">
            <div className="legend-dot" style={{ backgroundColor: '#4CAF50' }}></div>
            <span>Completed</span>
          </div>
          <div className="legend-item">
            <div className="legend-dot" style={{ backgroundColor: '#f44336' }}></div>
            <span>Cancelled</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DoctorCalendar;
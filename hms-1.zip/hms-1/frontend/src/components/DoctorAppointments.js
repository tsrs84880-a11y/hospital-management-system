import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import '../styles/DoctorAppointments.css';

const DoctorAppointments = ({ showScheduleView = false }) => {
  const [appointments, setAppointments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const { getAuthHeader } = useAuth();

  useEffect(() => {
    fetchAppointments();
  }, []);

  const fetchAppointments = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/appointments', {
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeader()
        }
      });
      const data = await response.json();
      // Fix: Extract the appointments array from the nested response structure
      setAppointments(data.success && data.data ? data.data : []);
    } catch (error) {
      toast.error('Error fetching appointments');
      setAppointments([]); // Set empty array on error
    } finally {
      setLoading(false);
    }
  };

  const updateAppointmentStatus = async (appointmentId, newStatus) => {
    try {
      const response = await fetch(`http://localhost:5000/api/appointments/${appointmentId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeader()
        },
        body: JSON.stringify({ status: newStatus })
      });

      if (response.ok) {
        toast.success(`Appointment ${newStatus} successfully`);
        fetchAppointments();
      } else {
        toast.error('Error updating appointment');
      }
    } catch (error) {
      toast.error('Error updating appointment');
    }
  };

  const filteredAppointments = appointments.filter(appointment => {
    if (filter === 'all') return true;
    return appointment.status === filter;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'scheduled': return '#007bff';
      case 'completed': return '#28a745';
      case 'cancelled': return '#dc3545';
      case 'in-progress': return '#ffc107';
      default: return '#6c757d';
    }
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading appointments...</p>
      </div>
    );
  }

  return (
    <div className="doctor-appointments">
      <div className="section-header">
        <h2>{showScheduleView ? 'My Schedule' : 'My Appointments'}</h2>
        <div className="filter-controls">
          <select value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="all">All Appointments</option>
            <option value="scheduled">Scheduled</option>
            <option value="in-progress">In Progress</option>
            <option value="completed">Completed</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>
      </div>

      <div className="appointments-container">
        {filteredAppointments.map((appointment) => (
          <div key={appointment._id} className="appointment-card">
            <div className="appointment-header">
              <div className="appointment-info">
                <h3>{appointment.patientId?.name || 'Unknown Patient'}</h3>
                <p className="appointment-id">ID: {appointment.appointmentId}</p>
              </div>
              <div 
                className="appointment-status"
                style={{ backgroundColor: getStatusColor(appointment.status) }}
              >
                {appointment.status}
              </div>
            </div>
            
            <div className="appointment-details">
              <div className="detail-item">
                <span className="label">Date:</span>
                <span>{new Date(appointment.appointmentDate).toLocaleDateString()}</span>
              </div>
              <div className="detail-item">
                <span className="label">Time:</span>
                <span>{appointment.appointmentTime}</span>
              </div>
              <div className="detail-item">
                <span className="label">Reason:</span>
                <span>{appointment.reason}</span>
              </div>
              <div className="detail-item">
                <span className="label">Patient Contact:</span>
                <span>{appointment.patientId?.phone || 'Not available'}</span>
              </div>
            </div>
            
            {appointment.status === 'scheduled' && (
              <div className="appointment-actions">
                <button 
                  className="start-btn"
                  onClick={() => updateAppointmentStatus(appointment._id, 'in-progress')}
                >
                  Start Consultation
                </button>
                <button 
                  className="cancel-btn"
                  onClick={() => updateAppointmentStatus(appointment._id, 'cancelled')}
                >
                  Cancel
                </button>
              </div>
            )}
            
            {appointment.status === 'in-progress' && (
              <div className="appointment-actions">
                <button 
                  className="complete-btn"
                  onClick={() => updateAppointmentStatus(appointment._id, 'completed')}
                >
                  Mark Complete
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      {filteredAppointments.length === 0 && (
        <div className="no-data">
          <p>No appointments found for the selected filter</p>
        </div>
      )}
    </div>
  );
};

export default DoctorAppointments;
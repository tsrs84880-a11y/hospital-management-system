import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import '../styles/PatientManagement.css';

const PatientManagement = () => {
  const [patients, setPatients] = useState([]);
  const [filteredPatients, setFilteredPatients] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingPatient, setEditingPatient] = useState(null);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    dateOfBirth: '',
    age: '',
    gender: '',
    patientType: '',
    disease: '',
    emergencyContact: '',
    medicalHistory: ''
  });
  
  const { getAuthHeader } = useAuth();

  useEffect(() => {
    fetchPatients();
  }, []);

  // Filter patients when search term changes
  useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredPatients(patients);
    } else {
      const filtered = patients.filter(patient => 
        patient.patientId && patient.patientId.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredPatients(filtered);
    }
  }, [searchTerm, patients]);

  // Calculate age from date of birth
  const calculateAge = (dateOfBirth) => {
    if (!dateOfBirth) return '';
    const today = new Date();
    const birthDate = new Date(dateOfBirth);
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  };

  const fetchPatients = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/patients', {
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeader()
        }
      });
      const data = await response.json();
      
      // Handle the correct API response structure
      if (data.success && Array.isArray(data.patients)) {
        // Sort patients by creation date (newest first)
        const sortedPatients = data.patients.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
        setPatients(sortedPatients);
        setFilteredPatients(sortedPatients);
      } else {
        setPatients([]);
        setFilteredPatients([]);
        console.error('Invalid API response:', data);
      }
    } catch (error) {
      console.error('Fetch error:', error);
      toast.error('Error fetching patients');
      setPatients([]); // Ensure patients is always an array
      setFilteredPatients([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const url = editingPatient 
        ? `http://localhost:5000/api/patients/${editingPatient._id}`
        : 'http://localhost:5000/api/patients';
      
      const method = editingPatient ? 'PUT' : 'POST';
      
      // Calculate age from date of birth and prepare submit data
      const submitData = {
        ...formData,
        name: `${formData.firstName} ${formData.lastName}`,
        age: calculateAge(formData.dateOfBirth)
      };
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeader()
        },
        body: JSON.stringify(submitData)
      });

      if (response.ok) {
        toast.success(editingPatient ? 'Patient updated successfully' : 'Patient added successfully');
        fetchPatients();
        resetForm();
      } else {
        const error = await response.json();
        toast.error(error.message || 'Error saving patient');
      }
    } catch (error) {
      toast.error('Error saving patient');
    }
  };

  const handleEdit = (patient) => {
    setEditingPatient(patient);
    setFormData({
      firstName: patient.firstName || '',
      lastName: patient.lastName || '',
      email: patient.email,
      phone: patient.phone,
      address: patient.address,
      dateOfBirth: patient.dateOfBirth ? patient.dateOfBirth.split('T')[0] : '',
      age: patient.age || '',
      gender: patient.gender,
      patientType: patient.patientType || '',
      disease: patient.disease || '',
      emergencyContact: patient.emergencyContact,
      medicalHistory: patient.medicalHistory || ''
    });
    setShowModal(true);
  };

  const handleDelete = async (patientId) => {
    if (window.confirm('Are you sure you want to delete this patient?')) {
      try {
        const response = await fetch(`http://localhost:5000/api/patients/${patientId}`, {
          method: 'DELETE',
          headers: {
            ...getAuthHeader()
          }
        });

        if (response.ok) {
          toast.success('Patient deleted successfully');
          fetchPatients();
        } else {
          toast.error('Error deleting patient');
        }
      } catch (error) {
        toast.error('Error deleting patient');
      }
    }
  };

  const resetForm = () => {
    setFormData({
      firstName: '',
      lastName: '',
      email: '',
      phone: '',
      address: '',
      dateOfBirth: '',
      age: '',
      gender: '',
      patientType: '',
      disease: '',
      emergencyContact: '',
      medicalHistory: ''
    });
    setEditingPatient(null);
    setShowModal(false);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
    
    // Auto-calculate age when date of birth changes
    if (name === 'dateOfBirth') {
      setFormData(prev => ({
        ...prev,
        [name]: value,
        age: calculateAge(value)
      }));
    }
  };

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading patients...</p>
      </div>
    );
  }

  return (
    <div className="patient-management">
      <div className="section-header">
        <h2>Patient Management</h2>
        <button className="add-btn" onClick={() => setShowModal(true)}>
          + Add Patient
        </button>
      </div>

      {/* Search Box */}
      <div className="search-container">
        <input
          type="text"
          placeholder="Search by Patient ID..."
          value={searchTerm}
          onChange={handleSearchChange}
          className="search-input"
        />
        {searchTerm && (
          <button 
            className="clear-search-btn"
            onClick={() => setSearchTerm('')}
            title="Clear search"
          >
            ×
          </button>
        )}
      </div>

      <div className="patients-table">
        <table>
          <thead>
            <tr>
              <th>Patient ID</th>
              <th>Name</th>
              <th>Age</th>
              <th>Gender</th>
              <th>Type</th>
              <th>Disease</th>
              <th>Phone</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {Array.isArray(filteredPatients) && filteredPatients.map((patient) => (
              <tr key={patient._id}>
                <td>{patient.patientId}</td>
                <td>{`${patient.firstName} ${patient.lastName}`}</td>
                <td>{patient.age}</td>
                <td>{patient.gender}</td>
                <td>
                  <span className={`patient-type ${patient.patientType}`}>
                    {patient.patientType === 'inpatient' ? 'In-Patient' : 'Out-Patient'}
                  </span>
                </td>
                <td>{patient.disease}</td>
                <td>{patient.phone}</td>
                <td>
                  <button 
                    className="edit-btn"
                    onClick={() => handleEdit(patient)}
                  >
                    Edit
                  </button>
                  <button 
                    className="delete-btn"
                    onClick={() => handleDelete(patient._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {Array.isArray(filteredPatients) && filteredPatients.length === 0 && (
          <p className="no-data">
            {searchTerm ? `No patients found with ID containing "${searchTerm}"` : 'No patients found'}
          </p>
        )}
      </div>

      {showModal && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>{editingPatient ? 'Edit Patient' : 'Add New Patient'}</h3>
              <button className="close-btn" onClick={resetForm}>×</button>
            </div>
            <form onSubmit={handleSubmit} className="patient-form">
              <div className="form-row">
                <div className="form-group">
                  <label>First Name *</label>
                  <input
                    type="text"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Last Name *</label>
                  <input
                    type="text"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label>Email *</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Phone *</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label>Date of Birth *</label>
                  <input
                    type="date"
                    name="dateOfBirth"
                    value={formData.dateOfBirth}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Age</label>
                  <input
                    type="number"
                    name="age"
                    value={formData.age}
                    readOnly
                    className="readonly-field"
                  />
                </div>
              </div>
              
              <div className="form-row">
                <div className="form-group">
                  <label>Gender *</label>
                  <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Patient Type *</label>
                  <select
                    name="patientType"
                    value={formData.patientType}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Type</option>
                    <option value="inpatient">In-Patient</option>
                    <option value="outpatient">Out-Patient</option>
                  </select>
                </div>
              </div>
              
              <div className="form-group">
                <label>Disease/Condition *</label>
                <input
                  type="text"
                  name="disease"
                  value={formData.disease}
                  onChange={handleChange}
                  placeholder="e.g., Hypertension, Diabetes"
                  required
                />
              </div>
              
              <div className="form-group">
                <label>Emergency Contact</label>
                <input
                  type="tel"
                  name="emergencyContact"
                  value={formData.emergencyContact}
                  onChange={handleChange}
                  placeholder="Emergency contact number"
                />
              </div>
              
              <div className="form-group">
                <label>Address</label>
                <textarea
                  name="address"
                  value={formData.address}
                  onChange={handleChange}
                  rows="3"
                  placeholder="Patient's address"
                ></textarea>
              </div>
              
              <div className="form-group">
                <label>Medical History</label>
                <textarea
                  name="medicalHistory"
                  value={formData.medicalHistory}
                  onChange={handleChange}
                  rows="3"
                  placeholder="Previous medical conditions, allergies, etc."
                ></textarea>
              </div>
              
              <div className="form-actions">
                <button type="button" onClick={resetForm} className="cancel-btn">
                  Cancel
                </button>
                <button type="submit" className="submit-btn">
                  {editingPatient ? 'Update' : 'Add'} Patient
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PatientManagement;
import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import io from 'socket.io-client';
import '../styles/Dashboard.css';

const Dashboard = ({ userRole }) => {
  const [stats, setStats] = useState({
    totalPatients: 0,
    totalDoctors: 0,
    totalAppointments: 0
  });
  const [loading, setLoading] = useState(true);
  const [notifications, setNotifications] = useState([]);
  const { getAuthHeader, user } = useAuth();

  useEffect(() => {
    fetchDashboardData();
    
    // Initialize socket connection for real-time updates
    const socket = io('http://localhost:5000');
    
    // Join admin room for real-time updates
    socket.emit('join', { userId: user?.id, role: 'admin' });
    
    // Listen for real-time updates
    socket.on('statsUpdate', (updatedStats) => {
      setStats(prevStats => ({
        ...prevStats,
        ...updatedStats
      }));
      
      // Show notification for significant changes
      if (updatedStats.totalPatients !== undefined) {
        addNotification(`Patient count updated: ${updatedStats.totalPatients}`, 'info');
      }
      if (updatedStats.totalDoctors !== undefined && userRole !== 'doctor') {
        addNotification(`Doctor count updated: ${updatedStats.totalDoctors}`, 'info');
      }
      if (updatedStats.totalAppointments !== undefined) {
        addNotification(`Appointment count updated: ${updatedStats.totalAppointments}`, 'info');
      }
    });
    
    // Cleanup socket connection
    return () => {
      socket.disconnect();
    };
  }, [user, userRole]);

  const addNotification = (message, type) => {
    const notification = {
      id: Date.now(),
      message,
      type,
      timestamp: new Date()
    };
    
    setNotifications(prev => [notification, ...prev.slice(0, 4)]);
    
    // Auto remove notification after 5 seconds
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== notification.id));
    }, 5000);
  };

  const fetchDashboardData = async () => {
    try {
      const headers = {
        'Content-Type': 'application/json',
        ...getAuthHeader()
      };

      // Fetch stats
      const [patientsRes, doctorsRes, appointmentsRes] = await Promise.all([
        fetch('http://localhost:5000/api/patients', { headers }),
        fetch('http://localhost:5000/api/doctors', { headers }),
        fetch('http://localhost:5000/api/appointments', { headers })
      ]);

      const patients = await patientsRes.json();
      const doctors = await doctorsRes.json();
      const appointments = await appointmentsRes.json();

      // Fix: Access the correct nested properties based on API response structure
      setStats({
        totalPatients: (patients.success && patients.patients) ? patients.patients.length : 0,
        totalDoctors: (doctors.success && doctors.doctors) ? doctors.doctors.length : 0,
        totalAppointments: (appointments.success && appointments.data) ? appointments.data.length : 0
      });

    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      addNotification('Failed to load dashboard data', 'error');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading dashboard...</p>
      </div>
    );
  }

  return (
    <div className="dashboard">
      {/* Real-time Notifications */}
      {notifications.length > 0 && (
        <div className="notifications-container">
          {notifications.map((notification) => (
            <div key={notification.id} className={`notification ${notification.type}`}>
              <div className="notification-content">
                <span className="notification-message">{notification.message}</span>
                <span className="notification-time">
                  {notification.timestamp.toLocaleTimeString()}
                </span>
              </div>
              <button 
                className="notification-close"
                onClick={() => setNotifications(prev => prev.filter(n => n.id !== notification.id))}
              >
                ×
              </button>
            </div>
          ))}
        </div>
      )}
      
      <div className="stats-grid">
        <div className="stat-card patients">
          <div className="stat-icon">👥</div>
          <div className="stat-info">
            <h3>{stats.totalPatients}</h3>
            <p>Total Patients</p>
          </div>
          <div className="stat-indicator">
            <span className="live-indicator">●</span>
            <span className="live-text">Live</span>
          </div>
        </div>
        
        {/* Hide Total Doctors stat card for doctor users */}
        {userRole !== 'doctor' && (
          <div className="stat-card doctors">
            <div className="stat-icon">👨‍⚕️</div>
            <div className="stat-info">
              <h3>{stats.totalDoctors}</h3>
              <p>Total Doctors</p>
            </div>
            <div className="stat-indicator">
              <span className="live-indicator">●</span>
              <span className="live-text">Live</span>
            </div>
          </div>
        )}
        
        <div className="stat-card appointments">
          <div className="stat-icon">📅</div>
          <div className="stat-info">
            <h3>{stats.totalAppointments}</h3>
            <p>Total Appointments</p>
          </div>
          <div className="stat-indicator">
            <span className="live-indicator">●</span>
            <span className="live-text">Live</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
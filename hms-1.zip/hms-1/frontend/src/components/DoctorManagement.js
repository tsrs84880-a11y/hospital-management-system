import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';
import '../styles/DoctorManagement.css';

const DoctorManagement = () => {
  const [doctors, setDoctors] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [showCredentials, setShowCredentials] = useState(false);
  const [generatedCredentials, setGeneratedCredentials] = useState(null);
  const [editingDoctor, setEditingDoctor] = useState(null);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    age: '',
    gender: '',
    email: '',
    phone: '',
    specialization: '',
    experience: '',
    qualification: ''
  });
  const { getAuthHeader } = useAuth();

  useEffect(() => {
    fetchDoctors();
  }, []);

  const fetchDoctors = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/doctors', {
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeader()
        }
      });
      const data = await response.json();
      // Fix: Access data.doctors instead of data directly
      if (data.success) {
        setDoctors(data.doctors);
      } else {
        setDoctors([]);
        toast.error(data.message || 'Failed to fetch doctors');
      }
    } catch (error) {
      console.error('Error fetching doctors:', error);
      setDoctors([]);
      toast.error('Error fetching doctors');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const url = editingDoctor 
        ? `http://localhost:5000/api/doctors/${editingDoctor._id}`
        : 'http://localhost:5000/api/doctors';
      
      const method = editingDoctor ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...getAuthHeader()
        },
        body: JSON.stringify(formData)
      });

      const result = await response.json();
      
      if (response.ok) {
        if (!editingDoctor && result.credentials) {
          // Show generated credentials for new doctor
          setGeneratedCredentials(result.credentials);
          setShowCredentials(true);
        }
        
        toast.success(editingDoctor ? 'Doctor updated successfully!' : 'Doctor registered successfully!');
        fetchDoctors();
        resetForm();
      } else {
        toast.error(result.message || 'Operation failed');
      }
    } catch (error) {
      toast.error('Error saving doctor');
    }
  };

  const handleEdit = (doctor) => {
    setEditingDoctor(doctor);
    setFormData({
      firstName: doctor.firstName || '',
      lastName: doctor.lastName || '',
      age: doctor.age || '',
      gender: doctor.gender || '',
      email: doctor.email || '',
      phone: doctor.phone || '',
      specialization: doctor.specialization || '',
      experience: doctor.experience || '',
      qualification: doctor.qualification || ''
    });
    setShowForm(true);
  };

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this doctor?')) {
      try {
        const response = await fetch(`http://localhost:5000/api/doctors/${id}`, {
          method: 'DELETE',
          headers: {
            ...getAuthHeader()
          }
        });

        if (response.ok) {
          toast.success('Doctor deleted successfully!');
          fetchDoctors();
        } else {
          toast.error('Delete failed');
        }
      } catch (error) {
        toast.error('Error deleting doctor');
      }
    }
  };

  const resetForm = () => {
    setFormData({
      firstName: '',
      lastName: '',
      age: '',
      gender: '',
      email: '',
      phone: '',
      specialization: '',
      experience: '',
      qualification: ''
    });
    setEditingDoctor(null);
    setShowForm(false);
  };

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    toast.success('Copied to clipboard!');
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Loading doctors...</p>
      </div>
    );
  }

  return (
    <div className="doctor-management">
      <div className="section-header">
        <h2>Doctor Management</h2>
        <button 
          className="add-btn"
          onClick={() => setShowForm(!showForm)}
        >
          {showForm ? 'Cancel' : '+ Register New Doctor'}
        </button>
      </div>

      {showForm && (
        <div className="modal-overlay">
          <div className="modal">
            <div className="modal-header">
              <h3>{editingDoctor ? 'Edit Doctor' : 'Register New Doctor'}</h3>
              <button className="close-btn" onClick={resetForm}>×</button>
            </div>
            <form onSubmit={handleSubmit} className="doctor-form">
              <div className="form-row">
                <div className="form-group">
                  <label>First Name *</label>
                  <input
                    type="text"
                    name="firstName"
                    value={formData.firstName}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Last Name *</label>
                  <input
                    type="text"
                    name="lastName"
                    value={formData.lastName}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Age *</label>
                  <input
                    type="number"
                    name="age"
                    value={formData.age}
                    onChange={handleInputChange}
                    min="25"
                    max="70"
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Gender *</label>
                  <select
                    name="gender"
                    value={formData.gender}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Select Gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Email *</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>Phone *</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="form-row">
                <div className="form-group">
                  <label>Specialization *</label>
                  <select
                    name="specialization"
                    value={formData.specialization}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="">Select Specialization</option>
                    <option value="Cardiology">Cardiology</option>
                    <option value="Neurology">Neurology</option>
                    <option value="Orthopedics">Orthopedics</option>
                    <option value="Pediatrics">Pediatrics</option>
                    <option value="Dermatology">Dermatology</option>
                    <option value="ENT">ENT</option>
                    <option value="General Medicine">General Medicine</option>
                    <option value="Psychiatry">Psychiatry</option>
                    <option value="Radiology">Radiology</option>
                    <option value="Anesthesiology">Anesthesiology</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>Experience (years) *</label>
                  <input
                    type="number"
                    name="experience"
                    value={formData.experience}
                    onChange={handleInputChange}
                    min="0"
                    max="50"
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <label>Qualification *</label>
                <input
                  type="text"
                  name="qualification"
                  value={formData.qualification}
                  onChange={handleInputChange}
                  placeholder="e.g., MBBS, MD, MS"
                  required
                />
              </div>

              <div className="form-actions">
                <button type="button" onClick={resetForm} className="cancel-btn">
                  Cancel
                </button>
                <button type="submit" className="submit-btn">
                  {editingDoctor ? 'Update Doctor' : 'Register Doctor'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Credentials Modal */}
      {showCredentials && generatedCredentials && (
        <div className="modal-overlay">
          <div className="modal credentials-modal">
            <div className="modal-header">
              <h3>🎉 Doctor Registered Successfully!</h3>
              <button className="close-btn" onClick={() => setShowCredentials(false)}>×</button>
            </div>
            <div className="credentials-content">
              <p className="credentials-info">
                The system has automatically generated login credentials for the new doctor:
              </p>
              
              <div className="credential-item">
                <label>Username:</label>
                <div className="credential-value">
                  <span>{generatedCredentials.username}</span>
                  <button 
                    className="copy-btn"
                    onClick={() => copyToClipboard(generatedCredentials.username)}
                  >
                    📋 Copy
                  </button>
                </div>
              </div>
              
              <div className="credential-item">
                <label>Password:</label>
                <div className="credential-value">
                  <span className="password-text">{generatedCredentials.password}</span>
                  <button 
                    className="copy-btn"
                    onClick={() => copyToClipboard(generatedCredentials.password)}
                  >
                    📋 Copy
                  </button>
                </div>
              </div>
              
              <div className="credentials-warning">
                ⚠️ <strong>Important:</strong> Please save these credentials securely and share them with the doctor. 
                This information will not be shown again for security reasons.
              </div>
              
              <button 
                className="close-credentials-btn"
                onClick={() => setShowCredentials(false)}
              >
                I've Saved the Credentials
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="doctors-table">
        <table>
          <thead>
            <tr>
              <th>Name</th>
              <th>Age</th>
              <th>Gender</th>
              <th>Specialization</th>
              <th>Experience</th>
              <th>Username</th>
              <th>Phone</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {doctors.map(doctor => (
              <tr key={doctor._id}>
                <td>{`${doctor.firstName} ${doctor.lastName}`}</td>
                <td>{doctor.age}</td>
                <td>{doctor.gender}</td>
                <td>{doctor.specialization}</td>
                <td>{doctor.experience} years</td>
                <td className="username-cell">{doctor.username}</td>
                <td>{doctor.phone}</td>
                <td>
                  <button 
                    className="edit-btn"
                    onClick={() => handleEdit(doctor)}
                  >
                    Edit
                  </button>
                  <button 
                    className="delete-btn"
                    onClick={() => handleDelete(doctor._id)}
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {doctors.length === 0 && (
          <p className="no-data">No doctors registered yet</p>
        )}
      </div>
    </div>
  );
};

export default DoctorManagement;